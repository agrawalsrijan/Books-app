import React from "react";

import "./cart-item.styles.css";

const CartItem = ({ item: { title, price, quantity } }) => {
  return (
    <div className="cart-item">
      <div className="item-details">
        <span className="name">{title}</span>
        <span className="price">
          {quantity} x ${price}
        </span>
      </div>
    </div>
  );
};

export default CartItem;
