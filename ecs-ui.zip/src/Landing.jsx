import React, { useState, useEffect } from "react";
import axios from "axios";

import BooksTable from "./components/bookstable/BooksTable";

const Landing = () => {
  let [booksData, setBooksData] = useState([]);

  useEffect(async () => {
    let response = await axios.get(
      "https://s3-ap-southeast-1.amazonaws.com/he-public-data/books8f8fe52.json"
    );

    console.log(response.data);
    setBooksData(response.data);
  }, []);

  if (booksData.length > 0) {
    return (
      <React.Fragment>
        <BooksTable booksData={booksData} />
      </React.Fragment>
    );
  } else {
    return (
      <React.Fragment>
        <h1>No data</h1>
      </React.Fragment>
    );
  }
};

export default Landing;
